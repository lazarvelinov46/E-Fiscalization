import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class KategorijaService {
  constructor(private http:HttpClient) { }
  uri = 'http://localhost:4000'

  dohvatiKategorije(pib){
    const data={
      pib:pib
    }
    return this.http.post(`${this.uri}/kategorije/dohvatisve`,data)
  }
  dodajKategoriju(pib,naziv,potkategorije){
    const data={
      pib:pib,
      naziv:naziv,
      potkategorije:potkategorije
    }
    return this.http.post(`${this.uri}/kategorije/dodaj`,data)
  }
  dodajPotkategoriju(pib,naziv,potkategorije){
    const data={
      pib:pib,
      naziv:naziv,
      potkategorije:potkategorije
    }
    return this.http.post(`${this.uri}/kategorije/dodajpotkategoriju`,data)
  }
}
