import { TestBed } from '@angular/core/testing';

import { NarucilacService } from './narucilac.service';

describe('NarucilacService', () => {
  let service: NarucilacService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NarucilacService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
