import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArtiklService {

  constructor(private http:HttpClient) { }
  uri = 'http://localhost:4000'

  unesiArtikl(pib, sifra,naziv,jedinicaMere,poreskaStopa,vrsta,zemljaPorekla,straniNaziv,barkod,proizvodjac,carinskaTarifa,
    ekoTaksa,akcize,minZalihe,maxZalihe,opis,deklaracija,robamagacin,robaobjekat,slika){
    const data = {
      pib:pib,
      sifra:sifra,
      naziv:naziv,
      jedinicaMere:jedinicaMere,
      poreskaStopa:poreskaStopa,
      vrsta:vrsta,
      zemljaPorekla:zemljaPorekla,
      straniNaziv:straniNaziv,
      barkod:barkod,
      proizvodjac:proizvodjac,
      carinskaTarifa:carinskaTarifa,
      ekoTaksa:ekoTaksa,
      akcize:akcize,
      minZalihe:minZalihe,
      maxZalihe:maxZalihe,
      opis:opis,
      deklaracija:deklaracija,
      slika:slika,
      robamagacin:robamagacin,
      robaobjekat:robaobjekat
    }
    return this.http.post(`${this.uri}/artikli/unesi`, data)
  }
  izmeni(pib,sifra,naziv,jedinicaMere,poreskaStopa,vrsta,zemljaPorekla,straniNaziv,barkod,proizvodjac,carinskaTarifa,
    ekoTaksa,akcize,minZalihe,maxZalihe,opis,deklaracija,robamagacin,robaobjekat,slika){
    const data = {
      pib:pib,
      sifra:sifra,
      naziv:naziv,
      jedinicaMere:jedinicaMere,
      poreskaStopa:poreskaStopa,
      vrsta:vrsta,
      zemljaPorekla:zemljaPorekla,
      straniNaziv:straniNaziv,
      barkod:barkod,
      proizvodjac:proizvodjac,
      carinskaTarifa:carinskaTarifa,
      ekoTaksa:ekoTaksa,
      akcize:akcize,
      minZalihe:minZalihe,
      maxZalihe:maxZalihe,
      opis:opis,
      deklaracija:deklaracija,
      slika:slika,
      robamagacin:robamagacin,
      robaobjekat:robaobjekat
    }
    return this.http.post(`${this.uri}/artikli/izmeni`, data)
  }

  dohvatiArtikleZaPreduzece(pib){
    const data={
      pib:pib
    }
    return this.http.post(`${this.uri}/artikli/dohvatisve`,data)
  }
  obrisiArtikl(pib,sifra){
    const data={
      pib:pib,
      sifra:sifra
    }
    return this.http.post(`${this.uri}/artikli/obrisi`,data)
  }
  dodajKategoriju(pib,sifra,kategorija,potkategorija){
    const data={
      pib:pib,
      sifra:sifra,
      kategorija:kategorija,
      potkategorija:potkategorija
    }
    return this.http.post(`${this.uri}/artikli/dodajkategoriju`,data)
  }
  smanjiMagacin(pib,sifra,robamagacin){
    const data = {
      pib:pib,
      sifra:sifra,
      robamagacin:robamagacin
    }
    return this.http.post(`${this.uri}/artikli/smanjimagacin`, data)
  }
  smanjiObjekat(pib,sifra,robaobjekat){
    const data = {
      pib:pib,
      sifra:sifra,
      robaobjekat:robaobjekat
    }
    return this.http.post(`${this.uri}/artikli/smanjiobjekat`, data)
  }
  dohvatiCeluBazu(){
    return this.http.get(`${this.uri}/artikli/dohvaticelubazu`)
  }

  pretragaNaziv(naziv){
    return this.http.get(`${this.uri}/artikli/dohvatiponazivu?param=${naziv}`)
  }
  pretragaProizvodjac(proizvodjac){
    return this.http.get(`${this.uri}/artikli/dohvatipoproizvodjacu?param=${proizvodjac}`)
  }
}
