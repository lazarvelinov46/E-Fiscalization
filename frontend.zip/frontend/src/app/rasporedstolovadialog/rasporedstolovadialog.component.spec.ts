import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RasporedstolovadialogComponent } from './rasporedstolovadialog.component';

describe('RasporedstolovadialogComponent', () => {
  let component: RasporedstolovadialogComponent;
  let fixture: ComponentFixture<RasporedstolovadialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RasporedstolovadialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RasporedstolovadialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
