import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Sto } from '../model/sto';
import { StoService } from '../sto.service';

@Component({
  selector: 'app-rasporedstolovadialog',
  templateUrl: './rasporedstolovadialog.component.html',
  styleUrls: ['./rasporedstolovadialog.component.css']
})
export class RasporedstolovadialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<RasporedstolovadialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private stoService:StoService) { }


  ngOnInit(): void {
    this.sto.pib=this.data.pib
    this.sto.odeljenje=this.data.naziv
    this.sto.objekat=this.data.objekat
  }
  sto:Sto=new Sto();
  sirina:number=0;
  visina:number=0;
  naziv:string;
  oblik:string;
  sirina2:number=0;
  unesi(){
    this.sto.naziv=this.naziv;
    this.sto.oblik=this.oblik
    if(this.oblik=='krug'){
      this.sto.sirina=this.sirina2
      this.sto.visina=this.sirina2
    }else{
      this.sto.sirina=this.sirina
      this.sto.visina=this.visina
    }
    if(this.sto.naziv==''||this.sto.oblik==''||this.sto.sirina==0||this.sto.visina==0){
      alert("Uneti sve podatke!!!")
      return;
    }
    this.dialogRef.close(this.sto)
  }
 

  close(){
    this.dialogRef.close();
  }
}
