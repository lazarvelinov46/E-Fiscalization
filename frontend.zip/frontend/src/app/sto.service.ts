import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StoService {

  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

  unesiSto(pib,objekat, odeljenje,naziv,oblik,sirina,visina,x,y){
    const data = {
      pib: pib,
      objekat:objekat,
      odeljenje:odeljenje,
      naziv:naziv,
      oblik:oblik,
      sirina:sirina,
      visina:visina,
      x:x,
      y:y
    }

    return this.http.post(`${this.uri}/stolovi/unesi`, data)
  }
  dohvatiStolove(pib,objekat,odeljenje){
    const data={
      pib:pib,
      objekat:objekat,
      odeljenje:odeljenje
    }
    
    return this.http.post(`${this.uri}/stolovi/dohvati`, data)
  }
  promeniSto(naziv,objekat,odeljenje,x,y){
    const data={
      naziv:naziv,
      objekat:objekat,
      odeljenje:odeljenje,
      x:x,
      y:y
    }
    
    return this.http.post(`${this.uri}/stolovi/promeni`, data)
  }
}
