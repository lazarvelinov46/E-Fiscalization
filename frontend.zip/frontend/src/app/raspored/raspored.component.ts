import { Component, Inject, OnInit } from '@angular/core';
import { KategorijaService } from '../kategorija.service';
import { Kategorija } from '../model/kategorija';
import { MatDialog,MatDialogConfig} from  '@angular/material/dialog';
import { DialogcomponentComponent } from '../dialogcomponent/dialogcomponent.component';
import { Router } from '@angular/router';
import { Preduzece } from '../model/preduzece';

@Component({
  selector: 'app-raspored',
  templateUrl: './raspored.component.html',
  styleUrls: ['./raspored.component.css']
})
export class RasporedComponent implements OnInit {

  constructor(private kategorijaService:KategorijaService,private  dialog:MatDialog,private router:Router) { }

  ngOnInit(): void {
    this.kategorije=new Array<Kategorija>()
    this.pib=localStorage.getItem('pib')
    this.preduzece=JSON.parse(localStorage.getItem('preduzece'));
    this.kategorijaService.dohvatiKategorije(this.pib).subscribe((data:Kategorija[])=>{
      if(data){
      this.kategorije=data
      }
    })
  }
  openDialog(index) {
    let dialogRef = this.dialog.open(DialogcomponentComponent, {
      width: '300px',
      data: { kat: this.kategorije[index].naziv, potkat: this.odabPotk[index] }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.message = result;
    });
    
}
  preduzece:Preduzece;
  pib:string;
  kategorije:Array<Kategorija>;
  novaKat:string='';
  katUnos:Kategorija=new Kategorija()
  potkatUnos:string[]=[];
  message:string;
  odabPotk:string[]=[];
  
  unesiKat(){
    if(this.novaKat==''){
      this.message='nekorektan unos'
      return;
    }
    let potkategorije=new Array<string>()
    this.kategorijaService.dodajKategoriju(this.pib,this.novaKat,potkategorije).subscribe(respObj=>{
      if(respObj['message']=='ok'){
        this.kategorijaService.dohvatiKategorije(this.pib).subscribe((data:Kategorija[])=>{
          this.kategorije=data
        })
      }
      else if(respObj['message']=='error'){
        this.message = 'greska'
      }
    })
    this.novaKat=""
  }

  unesiPotkategoriju(index){
    if(this.potkatUnos[index]==''||this.potkatUnos[index]==null){
      this.message="Nekorektan unos"
      return;
    }
    this.kategorije[index].potkategorije.push(this.potkatUnos[index]);
    this.kategorijaService.dodajPotkategoriju(this.pib,this.kategorije[index].naziv,this.kategorije[index].potkategorije).subscribe(respObj=>{
      if(respObj['message']=='ok'){
        this.kategorijaService.dohvatiKategorije(this.pib).subscribe((data:Kategorija[])=>{
          this.kategorije=data
        })
      }
      else if(respObj['message']=='error'){
        this.message = 'greska'
      }
    })
    this.potkatUnos[index]="";
  }
  trackByIndex(index: number, obj: any): any {
    return index;
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
