import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Preduzece } from '../model/preduzece';
import { Racun } from '../model/racun';
import { Stavka } from '../model/stavka';
import { PreduzeceService } from '../preduzece.service';
import { RacunService } from '../racun.service';

@Component({
  selector: 'app-pregledizvestaja',
  templateUrl: './pregledizvestaja.component.html',
  styleUrls: ['./pregledizvestaja.component.css']
})
export class PregledizvestajaComponent implements OnInit {

  constructor(private racunService:RacunService,private preduzeceService:PreduzeceService,private router:Router) { }

  ngOnInit(): void {
    this.pib=localStorage.getItem('pib')
    this.racunService.dohvatiRacune(this.pib).subscribe((data:Racun[])=>{
      if(data){
        this.racuni=data;
      }
    })
    this.preduzeceService.dohvatiPoPib(this.pib).subscribe((data2:Preduzece)=>{
      if(data2){
        this.preduzece=data2
        this.pdv=this.preduzece.pdv
      }
    })
  }
  pib:string
  vlasnik:string;
  racuni:Array<Racun>=new Array<Racun>()
  pazarVrednost:number=0
  pazarPorez:number=0
  pdv:boolean
  preduzece:Preduzece
  message:string
  racunid:number
  dan:Date
  stavke:Array<Stavka>=new Array<Stavka>()
  obracunajPazar(){
    this.pazarVrednost=0;
    this.pazarPorez=0;
    let danas=new Date(this.dan).toDateString()
    
    this.message=danas
    this.racuni.forEach(rac => {
      let rd=new Date(rac.datum).toDateString()
      if(rd==danas){
        this.pazarVrednost+=rac.cena
        this.pazarPorez+=rac.porez
      }
      
    });
  }
  prikaziStavke(){
    this.racuni.forEach(rac => {
      if(rac.idp==this.racunid){
        this.stavke=rac.stavke
      }
    });
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
