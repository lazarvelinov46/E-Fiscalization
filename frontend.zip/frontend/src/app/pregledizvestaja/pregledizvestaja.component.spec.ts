import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PregledizvestajaComponent } from './pregledizvestaja.component';

describe('PregledizvestajaComponent', () => {
  let component: PregledizvestajaComponent;
  let fixture: ComponentFixture<PregledizvestajaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PregledizvestajaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PregledizvestajaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
