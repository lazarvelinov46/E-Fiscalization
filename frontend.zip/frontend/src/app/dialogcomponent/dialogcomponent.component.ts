import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Artikl } from '../model/artikl';
import { ArtiklService } from '../artikl.service';

@Component({
  selector: 'app-dialogcomponent',
  templateUrl: './dialogcomponent.component.html',
  styleUrls: ['./dialogcomponent.component.css']
})
export class DialogcomponentComponent implements OnInit {

  
  constructor(
    public dialogRef: MatDialogRef<DialogcomponentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private artiklService:ArtiklService) { }
  
  onCancel(): void {
    this.dialogRef.close();
  }
    pib:string
    artikli:Array<Artikl>=new Array<Artikl>()
    pretraga:string
    message:string

    ngOnInit() {
      this.pib=localStorage.getItem('pib')
      this.artiklService.dohvatiArtikleZaPreduzece(this.pib).subscribe((data2:Array<Artikl>)=>{
        this.artikli=data2;
      })
    }

    save() {
        this.dialogRef.close();
    }
    

    close() {
        this.dialogRef.close();
    }
    odaberi(artikl){
      this.artiklService.dodajKategoriju(this.pib,artikl.sifra,this.data.kat,this.data.potkat).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.message = 'Uspesno unet artikl'
          
        }
        else if(respObj['message']=='postoji'){
          this.message = 'Artikl vec ima kategoriju'
        }
        else{
          this.message='error'
        }
        this.dialogRef.close(this.message)
      })
    }
    pretrazi(){
      this.artiklService.pretragaNaziv(this.pretraga).subscribe((data:Artikl[])=>{
        if(data){
          this.artikli=new Array<Artikl>()
          data.forEach(element => {
            if(element.pib==this.pib){
              this.artikli.push(element)
            }
          });
        }
      })
    }

}
