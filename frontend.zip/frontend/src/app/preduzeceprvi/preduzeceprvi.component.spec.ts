import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PreduzeceprviComponent } from './preduzeceprvi.component';

describe('PreduzeceprviComponent', () => {
  let component: PreduzeceprviComponent;
  let fixture: ComponentFixture<PreduzeceprviComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PreduzeceprviComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PreduzeceprviComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
