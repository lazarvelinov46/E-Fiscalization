
import { Component, OnInit } from '@angular/core';
import { Banka } from '../model/banka';
import { Magacin } from '../model/magacin';
import { Kasa } from '../model/kasa';
import { PreduzeceService } from '../preduzece.service';
import { Korisnik } from '../model/korisnik';
import { Router } from '@angular/router';

@Component({
  selector: 'app-preduzeceprvi',
  templateUrl: './preduzeceprvi.component.html',
  styleUrls: ['./preduzeceprvi.component.css']
})
export class PreduzeceprviComponent implements OnInit {

  constructor(private preduzeceService:PreduzeceService,private router:Router) { }

  ngOnInit(): void {
    this.sifrarnik=["kafic","market","kafana","trafika"];
    
    this.modelikase=["samsung","apple","Ei nis"];
    this.pdv=false;
  }
  sifrarnik:string[]=[]
  modelikase:string[]=[]
  kategorija:string
  sifre:Array<string>=[]
  pdv:boolean
  banka:string=""
  racun:string=""
  banke:Array<Banka>=[]
  brMag:number=1
  magacini:Array<Magacin>
  brojKasa:number=1
  kase:Array<Kasa>
  message:string
  korisnik:Korisnik
  
  racunIzraz = new RegExp("^[0-9]{3}\\-[0-9]{12}\\-[0-9]{2}$");

  
  onChange(sifra){
    
    this.sifre.push(sifra);
    /*
    if(this.sifre.includes(sifra)){
      const index: number = this.sifre.indexOf(sifra);
      this.sifre.splice(index, 1);
    }else{
      this.sifre.push(sifra);
    }
    */
  }
  trackByIndex(index: number, obj: any): any {
    return index;
  }
  dodajBanku(){
    
    if(this.racunIzraz.test(this.racun)==false){
      this.message="Bankovni racun nije u odgovarajucem obliku!!!"
      return;
    }
    let b=new Banka()
    b.banka=this.banka
    b.racun=this.racun
    this.banke.push(b)
    this.message="Dodata banka"
    document.getElementById('ban').ariaValueText=""
    
    document.getElementById('ziro').ariaValueText=""
    this.banka="";
    this.racun="";
  }

  potvrdiBrojMagacina(){
    this.magacini=[]
    for(let i=0;i<this.brMag;i++){

      this.magacini[i]=new Magacin()
      
    }
    
  }
  potvrdiBrojKasa(){
    this.kase=[]
    for(let i=0;i<this.brojKasa;i++){

      this.kase[i]=new Kasa()
    }
    
  }

  zavrsiRegistraciju(){
    if(this.sifre.length==0||this.banke.length==0||this.magacini.length==0||this.kase.length==0){
      this.message="Nisu uneti svi potrebni podaci"
      return;
    }
    this.korisnik=JSON.parse(localStorage.getItem('ulogovan'));
    for(let i=0;i<this.magacini.length;i++){
      for(let j=0;j<this.magacini.length;j++){
        if(j!=i){
          if(this.magacini[i].id==this.magacini[j].id){
            this.message="Imate 2 magacina sa istim id-jem"
            return;
          }
        }
      }
    }
    this.preduzeceService.zavrsiRegistraciju(this.korisnik.username,this.kategorija,this.sifre,this.pdv,this.banke,this.magacini,this.kase).subscribe(respObj=>{
      if(respObj['message']=='err kategorija'){
        
        this.message = 'greska'
      }
      else{
        this.message = 'Podaci uspesno dodati'
        this.router.navigate(['preduzece'])
      }
    })
  }
  
}
