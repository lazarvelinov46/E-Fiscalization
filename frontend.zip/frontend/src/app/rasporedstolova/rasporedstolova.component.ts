import { OverlayOutsideClickDispatcher } from '@angular/cdk/overlay';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Odeljenje } from '../model/odeljenje';
import { Preduzece } from '../model/preduzece';
import { Sto } from '../model/sto';
import { Zabranjeni } from '../model/zabranjeni';
import { OdeljenjeService } from '../odeljenje.service';
import { RasporedstolovadialogComponent } from '../rasporedstolovadialog/rasporedstolovadialog.component';
import { StoService } from '../sto.service';

@Component({
  selector: 'app-rasporedstolova',
  templateUrl: './rasporedstolova.component.html',
  styleUrls: ['./rasporedstolova.component.css']
})
export class RasporedstolovaComponent implements OnInit {

  constructor(private odeljenjeService:OdeljenjeService,private  dialog:MatDialog,private stoService:StoService,
    private router:Router) { }

  ngOnInit(): void {
    this.pib=localStorage.getItem('pib')
    this.zaizmenu=""
    this.preduzece=JSON.parse(localStorage.getItem('preduzece'))
    this.objekat=this.preduzece.kase[0].lokacija
    this.odeljenjeService.dohvatiOdeljenja(this.pib,this.objekat).subscribe((data:Odeljenje[])=>{
      if(data){
        this.odeljenja=data
        this.post=true
        //this.promeniOdeljenje(this.odeljenja[0].naziv);
      }

    })
  }
  preduzece:Preduzece
  objekat:string;
  pib:string;
  nazivOdeljenja:string='';
  message:string;
  odeljenja:Array<Odeljenje>=new Array<Odeljenje>()
  stolovi:Array<Sto>=new Array<Sto>()
  sto:Sto=new Sto()
  x:number
  post:boolean
  y:number
  i:number=0
  trenutnoOdeljenje:Odeljenje;
  zaizmenu:string="";
  zabranjeni:Array<Zabranjeni>=new Array<Zabranjeni>();
  moze:boolean=true
  zaiz:boolean=false;
  unosod:boolean=false;
  spremi:boolean=true;
  objekti:Array<String>=new Array<String>();
  izmeniPoziciju(){
    this.zaiz=true
  }
  promeniObjekat(){
    this.odeljenjeService.dohvatiOdeljenja(this.pib,this.objekat).subscribe((data:Odeljenje[])=>{
      
        this.odeljenja=data
        this.post=true
      this.promeniOdeljenje(this.odeljenja[0].naziv);
    })
  }
  promeniOdeljenje(odeljenje){
    
    this.sto=null;
    this.trenutnoOdeljenje=odeljenje
    const canvas=document.getElementById("canv")as HTMLCanvasElement | null;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    this.stoService.dohvatiStolove(this.pib,this.objekat,odeljenje).subscribe((data2:Sto[])=>{
      if(data2){
        this.stolovi=data2
        this.zabranjeni=new Array<Zabranjeni>();
        let i=0
        this.stolovi.forEach(astal=>{
          if(astal.oblik=='krug'){
            this.zabranjeni[i]=new Zabranjeni()
            this.zabranjeni[i].naziv=astal.naziv
            this.zabranjeni[i].x=astal.x-astal.sirina      
            this.zabranjeni[i].y=astal.y-astal.visina
            this.zabranjeni[i].width=astal.sirina*2
            this.zabranjeni[i].height=astal.visina*2
            i++
          }else{
            this.zabranjeni[i]=new Zabranjeni()
            this.zabranjeni[i].naziv=astal.naziv
            this.zabranjeni[i].x=astal.x          
            this.zabranjeni[i].y=astal.y
            this.zabranjeni[i].width=astal.sirina
            this.zabranjeni[i].height=astal.visina
            i++
          }
          this.x=astal.x
          this.y=astal.y
          this.sto=astal
          this.iscrtajSto()
          this.sto=null
        })
      }
      
    })
  }
  refresh(){
    this.stolovi.forEach(astal=>{
      this.x=astal.x
      this.y=astal.y
      this.sto=astal
      this.iscrtajSto()
      this.sto=null
    })
  }
  check(){
    let tempx
    let tempy
    let tempv
    let temps
    if(this.sto.oblik=='krug'){
      tempx=this.x-this.sto.sirina
      tempy=this.y-this.sto.visina
      tempv=this.sto.visina*2
      temps=this.sto.sirina*2
    }else{
      tempx=this.x
      tempy=this.y
      tempv=this.sto.visina
      temps=this.sto.sirina
    }
    this.zabranjeni.forEach(z => {
      if(this.zaizmenu!=""&&z.naziv==this.sto.naziv){

      }else{
      if((tempx>z.x)&&(tempx<z.x+z.width)){
        if((tempy>z.y)&&(tempy<z.y+z.height)){
          this.moze=false
        }else if((tempy<z.y)&&((tempy+tempv>z.y))){
          this.moze=false
        }
      }else if((tempx<z.x)&&(tempx+temps>z.x)){
        if(tempy<z.y&&tempy+tempv>z.y){
          this.moze=false
        }else if((tempy>z.y)&&(tempy<z.y+z.height)){
          this.moze=false
        }
      }
    }
    });
  }
  
  unesiOdeljenje(){
    if(this.nazivOdeljenja==''){
      this.unosod=false;
      this.spremi=true;
    }else{
    this.odeljenjeService.unesiOdeljenje(this.pib,this.objekat,this.nazivOdeljenja).subscribe(respObj=>{
      if(respObj['message']==['ok']){
        this.odeljenjeService.dohvatiOdeljenja(this.pib,this.objekat).subscribe((data:Odeljenje[])=>{
          if(data){
            this.odeljenja=data
          }
          
        })
        this.unosod=false;
        this.spremi=true;
        this.nazivOdeljenja=''
      }else{
        this.message='error'
      }
    })
  }
  }
  spremiUnos(){
    this.spremi=false;
    this.unosod=true;
  }
  dodajSto(){
    let naziv=this.trenutnoOdeljenje
    let dialogRef = this.dialog.open(RasporedstolovadialogComponent, {
      width: '300px',
      data: { pib: this.pib,objekat:this.objekat, naziv: naziv }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.sto=result
      
      
      this.post=false
    });
  }
  iscrtajSto(){
    const canvas=document.getElementById("canv")as HTMLCanvasElement | null;
    const ctx = canvas.getContext('2d');
    
    if(this.sto.oblik=='krug'){
      ctx.beginPath();
      ctx.arc(this.x,this.y,this.sto.sirina,0,2*Math.PI)
      ctx.stroke();
      ctx.strokeText(this.sto.naziv,this.x,this.y)
    }else{
    ctx.strokeRect(this.x,this.y,this.sto.sirina,this.sto.visina);
    
    ctx.strokeText(this.sto.naziv,this.x+this.sto.sirina/2,this.y+this.sto.visina/2)
    }
  }
  getCursorPosition(canvas, event) {
    
  }
  postaviSto(event){
    const canvas=document.getElementById("canv")as HTMLCanvasElement | null;
    // const rect = canvas.getBoundingClientRect()
    const rect = canvas.getBoundingClientRect()
    this.x = event.clientX - rect.left
    this.y = event.clientY - rect.top
    if(this.zaizmenu!=""){
      this.stolovi.forEach(sto => {
        if(this.zaizmenu==sto.naziv){
          this.sto=sto
          this.check()
          if(this.moze==false){
            this.message="Stolovi se preklapaju, probajte nove koordinate"
            this.moze=true;
          }else{
          this.stoService.promeniSto(sto.naziv,this.objekat,this.trenutnoOdeljenje,this.x,this.y).subscribe(respObj=>{
            if(respObj['message']=='err'){
              
              this.message='error'
            }else{
              this.zaizmenu=""
              
            this.message=""
              this.zaiz=false;
              this.promeniOdeljenje(this.trenutnoOdeljenje)
            }
          })
          this.sto=null
        }
        }
      });
    }else{
    if(this.sto){
      this.check()
    if(this.moze==false){
      this.message="Stolovi se preklapaju, probajte nove koordinate"
      this.moze=true;
    }else{
   
    this.iscrtajSto()
    let z =new Zabranjeni()
    if(this.sto.oblik=='krug'){
      z.naziv=this.sto.naziv
      z.x=this.x-this.sto.sirina       
      z.y=this.y-this.sto.visina
      z.width=this.sto.sirina*2
      z.height=this.sto.visina*2
    }else{
      z.naziv=this.sto.naziv
      z.x=this.x          
      z.y=this.y
      z.width=this.sto.sirina
      z.height=this.sto.visina
    }
    this.zabranjeni.push(z)
    this.stoService.unesiSto(this.sto.pib,this.objekat,this.sto.odeljenje,this.sto.naziv,this.sto.oblik,this.sto.sirina,this.sto.visina,
      this.x,this.y).subscribe(respObj=>{
      if(respObj['message']=='ok'){
        this.message=""
      }else{
        this.message=respObj['message']
        this.promeniOdeljenje(this.trenutnoOdeljenje)
      }
    })
    this.sto=null
  }
}
  }
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
