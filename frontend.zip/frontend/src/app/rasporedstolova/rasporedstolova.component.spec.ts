import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RasporedstolovaComponent } from './rasporedstolova.component';

describe('RasporedstolovaComponent', () => {
  let component: RasporedstolovaComponent;
  let fixture: ComponentFixture<RasporedstolovaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RasporedstolovaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RasporedstolovaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
