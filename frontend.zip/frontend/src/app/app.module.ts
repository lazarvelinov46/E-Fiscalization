import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { PreduzeceComponent } from './preduzece/preduzece.component';
import { AdministratorComponent } from './administrator/administrator.component';
import { HttpClientModule } from '@angular/common/http';
import { KupacComponent } from './kupac/kupac.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { PreduzeceprviComponent } from './preduzeceprvi/preduzeceprvi.component';
import { NaruciociComponent } from './narucioci/narucioci.component';
import { RobeuslugeComponent } from './robeusluge/robeusluge.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatPaginatorModule} from '@angular/material/paginator'
import {MatTabsModule} from'@angular/material/tabs';
import { RasporedComponent } from './raspored/raspored.component'

import {MatDialogModule } from '@angular/material/dialog';
import {MatInputModule} from '@angular/material/input';
import {MatButtonModule} from '@angular/material/button';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import { DialogcomponentComponent } from './dialogcomponent/dialogcomponent.component';
import { RobeuslugedialogComponent } from './robeuslugedialog/robeuslugedialog.component';
import { RasporedstolovaComponent } from './rasporedstolova/rasporedstolova.component';
import { RasporedstolovadialogComponent } from './rasporedstolovadialog/rasporedstolovadialog.component';
import { IzdavanjeracunaComponent } from './izdavanjeracuna/izdavanjeracuna.component';
import { PregledizvestajaComponent } from './pregledizvestaja/pregledizvestaja.component';
import { PregledracunaComponent } from './pregledracuna/pregledracuna.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
import { MatTableModule } from '@angular/material/table';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    PreduzeceComponent,
    AdministratorComponent,
    KupacComponent,
    ChangepasswordComponent,
    PreduzeceprviComponent,
    NaruciociComponent,
    RobeuslugeComponent,
    RasporedComponent,
    DialogcomponentComponent,
    RobeuslugedialogComponent,
    RasporedstolovaComponent,
    RasporedstolovadialogComponent,
    IzdavanjeracunaComponent,
    PregledizvestajaComponent,
    PregledracunaComponent,
    LoginadminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    MatTabsModule,
    HttpClientModule,
    MatPaginatorModule,
    BrowserAnimationsModule,
    MatDialogModule,
    MatInputModule,
    MatTableModule,
    MatButtonModule,
    MatCardModule,
    MatFormFieldModule
  ],
  providers: [
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
