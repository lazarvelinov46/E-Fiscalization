import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { KorisnikService } from '../korisnik.service';
import { Korisnik } from '../model/korisnik';
import { Racun } from '../model/racun';
import { PreduzeceService } from '../preduzece.service';
import { RacunService } from '../racun.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private korisnikService:KorisnikService,private router:Router,private preduzeceService:PreduzeceService,
    private racunService:RacunService) { }

  ngOnInit(): void {
    this.racunService.dohvatiSveRacune().subscribe((data:Racun[])=>{
      if(data){
        for(let i=0;i<5&&i<data.length;i++){
          this.racuni[i]=data[data.length-i-1];
        }
      }
    })
  }
//za login
  username:string;
  password:string;
  message:string;
  korisnik:Korisnik;
//za registraciju
  imeReg:string='';
  prezimeReg:string='';
  usernameReg:string='';
  passwordReg:string='';
  passwordReg2:string='';
  kontaktTel:string='';
  email:string='';
  naziv:string='';
  adresa:string='';
  pib:string='';
  matbroj:string='';
  messager:string;
  sifraIzraz = new RegExp("^[A-Za-z](?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{7,11}$");
  pibIzraz=new RegExp("^[1-9][0-9]{8}$");
  emailIzraz=new RegExp("^[a-z][a-z0-9]*@[a-z]+\\.[a-z]+$");
url:any;
  login(){
    this.korisnikService.login(this.username, this.password).subscribe((korisnikFromDB: Korisnik)=>{
      if(korisnikFromDB!=null){
        this.korisnik=korisnikFromDB;
        localStorage.setItem('ulogovan',JSON.stringify(korisnikFromDB))
        if(korisnikFromDB.vrsta=='kupac'){
          this.router.navigate(['kupac']);
        }
        else if(korisnikFromDB.vrsta=='admin'){
          //this.router.navigate(['administrator']);
          this.korisnik=null;
          this.message='Ovo nije prijava za administratora'
        }
        else{
          if(korisnikFromDB.prviPut){
            this.router.navigate(['preduzeceprvi']);
          }else{
            this.router.navigate(['preduzece'])
          }
        }
      }
      else{
        this.message="Pogresno korisnicko ime ili lozinka"
      }
    })
    
  }
  odaberiSliku(event: any){
    if(!event.target.files[0]||event.target.files[0].length==0){
      this.message="Nije uneta nijedna slika";
      return;
    }
    let tip=event.target.files[0].type;
    if(tip.match(/image\/*/)==null){
      this.message="Tip nije slika";
      return;
    }
    let citac=new FileReader();
    citac.readAsDataURL(event.target.files[0]);

    citac.onload=(_event)=>{
      let slika=new Image();
      slika.onload=(event_slika:any)=>{
        if(slika.width>300 || slika.width<100||slika.height>300||slika.height<100){
          this.message="Velicina slike nije u opsegu od 100x100 do 300x300"
        }
      }
      this.url=_event.target.result;
    }
    
  }
  register(){
    if(this.sifraIzraz.test(this.passwordReg)==false){
      this.messager="Sifra nije u odgovarajucem obliku!!!"
      return;
    }
    if(this.emailIzraz.test(this.email)==false){
      this.messager="Email nije u odgovarajucem obliku!!!"
      return;
    }
    if(this.pibIzraz.test(this.pib)==false){
      this.messager="PIB nije u odgovarajucem obliku!!!"
      return;
    }
    if(this.imeReg==''||this.prezimeReg==''||this.usernameReg==''||this.email==''||this.kontaktTel==''||this.adresa==''||this.pib==''
    ||this.matbroj==''){
      this.messager="Nisu uneti svi potrebni podaci!!!"
      return;
    }
    if(this.passwordReg!=this.passwordReg2){
      this.messager="Nisu iste sifre!!!"
    }else{
      this.preduzeceService.register(this.imeReg,this.prezimeReg,this.usernameReg,this.passwordReg,this.kontaktTel,
        this.email,this.naziv,this.adresa,this.pib,this.matbroj,true,this.url).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.messager = 'Poslat zahtev za dodavanje preduzeca'
        }
        else{
          this.messager = respObj['message']
        }
      })
    }
    
  }
  //poslednjih 5 racuna
  racuni:Array<Racun>=new Array<Racun>()
  


}
