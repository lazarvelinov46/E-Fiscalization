import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class KorisnikService {

  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

  login(usernameFromForm, passwordFromForm){
    const data = {
      username: usernameFromForm,
      password: passwordFromForm
    }

    return this.http.post(`${this.uri}/korisnici/login`, data)
  }
  loginAdmin(usernameFromForm, passwordFromForm){
    const data = {
      username: usernameFromForm,
      password: passwordFromForm
    }

    return this.http.post(`${this.uri}/korisnici/loginadmin`, data)
  }

  changePassword(username,password,starasif){
    const data={
      username:username,
      password:password,
      starasif:starasif
    }
    return this.http.post(`${this.uri}/korisnici/changepassword`, data)
  }

  dodajKupca(ime,prezime,username,password,telefon,licna){
    const data={
      ime:ime,
      prezime:prezime,
      username:username,
      password:password,
      telefon:telefon,
      licna:licna
    }
    
    return this.http.post(`${this.uri}/korisnici/dodajkupca`, data)
  }
}
