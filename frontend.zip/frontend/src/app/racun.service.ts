import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RacunService {
  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

    
    unesiRacun(pib,id,preduzece,objekat, stavke,cena,porez,odeljenje,sto){
      const data = {
        pib: pib,
        idp:id,
        preduzece:preduzece,
        objekat:objekat,
        stavke:stavke,
        cena:cena,
        porez:porez,
        odeljenje:odeljenje,
        sto:sto
      }
  
      return this.http.post(`${this.uri}/racuni/unesi`, data)
    }
    apdejtujRacun(pib,idp, stavke,cena,porez,odeljenje,sto){
      const data = {
        pib: pib,
        idp:idp,
        stavke:stavke,
        cena:cena,
        porez:porez,
        odeljenje:odeljenje,
        sto:sto
      }
  
      return this.http.post(`${this.uri}/racuni/apdejt`, data)
    }
    dohvatiRacune(pib){
      const data = {
        pib: pib
      }
  
      return this.http.post(`${this.uri}/racuni/dohvati`, data)
    }
    dohvatiSveRacune(){
  
      return this.http.get(`${this.uri}/racuni/dohvatisve`)
    }
    dohvatiLicna(licnaKarta){
      const data = {
        licnaKarta: licnaKarta
      }
  
      return this.http.post(`${this.uri}/racuni/dohvatilicna`, data)
    }
    
    //this.racunService.zatvoriGotovina(this.vrednost,kusur,this.lk)
    zatvoriGotovina(pib,idp,vrednost,kusur,lk,datum){
      const data={
        pib:pib,
        idp:idp,
        vrednost:vrednost,
        kusur:kusur,
        lk:lk,
        datum:datum
      }
      
      return this.http.post(`${this.uri}/racuni/zatvorigotovina`, data)
    }
    zatvoriCek(pib,idp,ime,prezime,lk,datum){
      const data={
        pib:pib,
        idp:idp,
        ime:ime,
        prezime:prezime,
        lk:lk,
        datum:datum
      }
      
      return this.http.post(`${this.uri}/racuni/zatvoricek`, data)
    }
    zatvoriKartica(pib,idp,lk,slipRacun,datum){
      const data={
        pib:pib,
        idp:idp,
        lk:lk,
        slipRacun:slipRacun,
        datum:datum
      }
      
      return this.http.post(`${this.uri}/racuni/zatvorikartica`, data)
    }
    zatvoriVirman(pib,idp,narucilac,datum){
      const data={
        pib:pib,
        idp:idp,
        narucilac:narucilac,
        datum:datum
      }
      
      return this.http.post(`${this.uri}/racuni/zatvorivirman`, data)
    }
}
