import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PreduzeceService {

  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

  register(imeReg, prezimeReg, usernameReg, passwordReg,kontaktTel,email,naziv,adresa,pib,matbroj ,prvi,slika){
    const data = {
      ime:imeReg,
      prezime:prezimeReg,
      username:usernameReg,
      password:passwordReg,
      kontaktTel:kontaktTel,
      email:email,
      naziv:naziv,
      adresa:adresa,
      pib:pib,
      matbroj:matbroj,
      prvi:prvi,
      slika:slika
    }

    return this.http.post(`${this.uri}/preduzeca/register`, data)
  }
  apdejtuj(username,imeReg, prezimeReg,kontaktTel,email,naziv,adresa,kategorija,sifre,pdv,banke,magacini,kase){
    const data = {
      username:username,
      ime:imeReg,
      prezime:prezimeReg,
      telefon:kontaktTel,
      email:email,
      naziv:naziv,
      adresa:adresa,
      kategorija:kategorija,
      sifre:sifre,
      pdv:pdv,
      banke:banke,
      magacini:magacini,
      kase:kase
    }

    return this.http.post(`${this.uri}/preduzeca/apdejtuj`, data)
  }
  aktiviraj(pib){
    const data={
      pib:pib
    }
    
    return this.http.post(`${this.uri}/preduzeca/aktiviraj`, data)
  }
  deaktiviraj(pib){
    const data={
      pib:pib
    }
    
    return this.http.post(`${this.uri}/preduzeca/deaktiviraj`, data)
  }

  dohvatiPreduzeca(){
    return this.http.get(`${this.uri}/preduzeca/dohvatipreduzeca`)
  }
  dohvatiPreduzece(vlasnik){
    const data={
      vlasnik:vlasnik
    }
    return this.http.post(`${this.uri}/preduzeca/dohvatipreduzece`,data)
  }
  dohvatiPoPib(pib){
    const data={
      pib:pib
    }
    return this.http.post(`${this.uri}/preduzeca/dohvatipopib`,data)
  }

  zavrsiRegistraciju(user,kategorija,sifre,pdv,banke,magacini,kase){
    const data={
      user:user,
      kategorija:kategorija,
      sifre:sifre,
      pdv:pdv,
      banke:banke,
      magacini:magacini,
      kase:kase
    }
    return this.http.post(`${this.uri}/preduzeca/zavrsiregistraciju`,data)
  }
  punaRegistracija(imeReg, prezimeReg, usernameReg, passwordReg,kontaktTel,email,naziv,adresa,pib,matbroj ,prvi,
    kategorija,sifre,pdv,banke,magacini,kase){
      const data={
        ime:imeReg,
        prezime:prezimeReg,
        username:usernameReg,
        password:passwordReg,
        kontaktTel:kontaktTel,
        email:email,
        naziv:naziv,
        adresa:adresa,
        pib:pib,
        matbroj:matbroj,
        prvi:prvi,
        kategorija:kategorija,
        sifre:sifre,
        pdv:pdv,
        banke:banke,
        magacini:magacini,
        kase:kase
      }
      return this.http.post(`${this.uri}/preduzeca/punaregistracija`,data)
  }

  pretraziPoPib(pib){
    
    return this.http.get(`${this.uri}/preduzeca/dohvatipreduzeca?param=${pib}`)
  }

}
