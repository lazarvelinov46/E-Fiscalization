import { ArrayType } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';

import { MatTable, MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ArtiklService } from '../artikl.service';
import { Artikl } from '../model/artikl';
import { Kasa } from '../model/kasa';
import { Korisnik } from '../model/korisnik';
import { Magacin } from '../model/magacin';
import { Preduzece } from '../model/preduzece';
import { RobaMagacin } from '../model/robamagacin';
import { RobaObjekat } from '../model/robaobjekat';
import { PreduzeceService } from '../preduzece.service';
import { RobeuslugedialogComponent } from '../robeuslugedialog/robeuslugedialog.component';

@Component({
  selector: 'app-robeusluge',
  templateUrl: './robeusluge.component.html',
  styleUrls: ['./robeusluge.component.css']
})
export class RobeuslugeComponent implements OnInit {

  constructor(private preduzeceService:PreduzeceService,private artiklService:ArtiklService,private  dialog:MatDialog,
    private router:Router) { }
    @ViewChild('paginator') paginator: MatPaginator;
    dataSource:MatTableDataSource<Artikl>
  ro:boolean=false
  sviartikli:Array<Artikl>=new Array<Artikl>()
  vlasnik:Korisnik
  preduzece:Preduzece
  sifra:string
  naziv:string
  jedinicaMere:string
  stopa:number
  vrstaArtikla:string
  stope:number[]=[]
  nemaPorez:boolean=false
  message:string
  columnsToDisplay:string[]=[]
//dopunski podaci
  zemljaPorekla:string
  straniNaziv:string
  barkod:string
  nazivProizvodjaca:string
  carinskaTarifa:number
  ekoTaksa:boolean
  akcize:boolean
  minZalihe:number
  maxZalihe:number
  opis:string
  deklaracija:string
  url:any=null
  //cena i stanje
  magacini:Array<Magacin>=new Array<Magacin>()
  nabavnaCena:number
  prodajnaCena:number
  stanjeLagera:number
  maxZeljenaKolicina:number
  minZeljenaKolicina:number
  robamagacin:Array<RobaMagacin>=new Array<RobaMagacin>()
  robaobjekat:Array<RobaObjekat>=new Array<RobaObjekat>()
  kase:Array<Kasa>=new Array<Kasa>();
  trackByIndex(index: number, obj: any): any {
    return index;
  }
  ngOnInit(): void {
    this.columnsToDisplay=['sifra','naziv','jedinicaMere','poreskaStopa','proizvodjac','izmena','brisanje']
    document.getElementById('mattabgrupa').style.display='none'
    
    document.getElementById('izmena').style.display='none'
    
    document.getElementById('unos').style.display='none'
    this.vlasnik=JSON.parse(localStorage.getItem('ulogovan'))
    this.preduzeceService.dohvatiPreduzece(this.vlasnik.username).subscribe((data:Preduzece)=>{
      this.magacini=data.magacini;
      
      this.kase=data.kase
      this.preduzece=data;
      this.artiklService.dohvatiArtikleZaPreduzece(this.preduzece.pib).subscribe((data2:Array<Artikl>)=>{
        this.sviartikli=data2;
        this.dataSource=new MatTableDataSource(this.sviartikli)
        this.dataSource.paginator=this.paginator
      })
      for(let i=0;i<data.magacini.length;i++){
        this.robamagacin[i]=new RobaMagacin();
      }
      for(let i=0;i<data.magacini.length;i++){
        this.robamagacin[i].idMagacin=data.magacini[i].id;
        this.robamagacin[i].nazivMagacin=data.magacini[i].naziv
      }
      
    })
    
  
    
    
  }
  odaberiSliku(event: any){
    if(!event.target.files[0]||event.target.files[0].length==0){
      this.message="Nije uneta nijedna slika";
      return;
    }
    let tip=event.target.files[0].type;
    if(tip.match(/image\/*/)==null){
      this.message="Tip nije slika";
      return;
    }
    let citac=new FileReader();
    citac.readAsDataURL(event.target.files[0]);

    citac.onload=(_event)=>{
      let slika=new Image();
      slika.onload=(event_slika:any)=>{
        if(slika.width>300 || slika.width<100||slika.height>300||slika.height<100){
          this.message="Velicina slike nije u opsegu od 100x100 do 300x300"
        }
      }
      this.url=_event.target.result;
    }
    
  }
  unesiArtikl(){
    if(this.url==null){
      this.url='../../assets/artikl.jpg'
    }
    this.message=''
    if(this.sifra==""||this.naziv==""||this.jedinicaMere==""||(this.stopa==0&&this.preduzece.pdv)||
    (this.vrstaArtikla==""&&this.preduzece.kategorija=='ugostiteljski objekat')){
      this.message="Nisu uneti svi potrebni podaci"
      return;
    }
    this.artiklService.unesiArtikl(this.preduzece.pib,this.sifra,this.naziv,this.jedinicaMere,this.stopa,this.vrstaArtikla,
      this.zemljaPorekla,this.straniNaziv,this.barkod,this.nazivProizvodjaca,this.carinskaTarifa,this.ekoTaksa,
      this.akcize,this.minZalihe,this.maxZalihe,this.opis,this.deklaracija,this.robamagacin,this.robaobjekat,this.url).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.message = 'Uspesno unet artikl'
          
          this.artiklService.dohvatiArtikleZaPreduzece(this.preduzece.pib).subscribe((data2:Array<Artikl>)=>{
            this.sviartikli=data2;
            this.dataSource=new MatTableDataSource(this.sviartikli)
            this.dataSource.paginator=this.paginator
          })
        }
        else {
          this.message = respObj['message']
        }
      })
      
    document.getElementById('mattabgrupa').style.display='none'
    document.getElementById('unos').style.display='none'
  }
  otvoriUnos(){
    this.message=''
    document.getElementById('mattabgrupa').style.display='block'
    this.sifra="";
    this.ro=false;
    this.naziv="";
    this.jedinicaMere="";
    this.stopa=0;
    this.vrstaArtikla="";
    this.zemljaPorekla="";
    this.straniNaziv="";
    this.barkod="";
    this.nazivProizvodjaca="";
    this.carinskaTarifa=0;
    this.ekoTaksa=false;
    this.akcize=false;
    this.minZalihe=0;
    this.maxZalihe=0;
    this.opis="";
    this.deklaracija="";
    this.robamagacin=new Array<RobaMagacin>();
    this.robaobjekat=new Array<RobaObjekat>();
    for(let i=0;i<this.magacini.length;i++){
      this.robamagacin[i]=new RobaMagacin();
    }
    for(let i=0;i<this.kase.length;i++){
      this.robaobjekat[i]=new RobaObjekat();
    }
    for(let i=0;i<this.magacini.length;i++){
      this.robamagacin[i].idMagacin=this.magacini[i].id;
      this.robamagacin[i].nazivMagacin=this.magacini[i].naziv
    }
    for(let i=0;i<this.kase.length;i++){
      this.robaobjekat[i].objekat=this.kase[i].lokacija
    }
    document.getElementById('izmena').style.display='none'
    
    document.getElementById('unos').style.display='block'
  }
  spremiIzmenu(artikl){
    this.message=''
    this.sifra=artikl.sifra;
    this.ro=true;
    this.naziv=artikl.naziv;
    this.jedinicaMere=artikl.jedinicaMere;
    this.stopa=artikl.poreskaStopa;
    this.vrstaArtikla=artikl.vrsta;
    this.zemljaPorekla=artikl.zemljaPorekla;
    this.straniNaziv=artikl.straniNaziv;
    this.barkod=artikl.barkod;
    this.nazivProizvodjaca=artikl.proizvodjac;
    this.carinskaTarifa=artikl.carinskaTarifa;
    this.ekoTaksa=artikl.ekoTaksa;
    this.akcize=artikl.akcize;
    this.minZalihe=artikl.minZalihe;
    this.maxZalihe=artikl.maxZalihe;
    this.opis=artikl.opis;
    this.deklaracija=artikl.deklaracija;
    this.robamagacin=artikl.robamagacin;
    this.robaobjekat=artikl.robaobjekat
    document.getElementById('mattabgrupa').style.display='block'
    
    document.getElementById('izmena').style.display='block'
    
    document.getElementById('unos').style.display='none'
  }
  izmeniArtikl(){
    this.ro=false;
    this.artiklService.izmeni(this.preduzece.pib,this.sifra,this.naziv,this.jedinicaMere,this.stopa,this.vrstaArtikla,
      this.zemljaPorekla,this.straniNaziv,this.barkod,this.nazivProizvodjaca,this.carinskaTarifa,this.ekoTaksa,
      this.akcize,this.minZalihe,this.maxZalihe,this.opis,this.deklaracija,this.robamagacin,this.robaobjekat,this.url).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.message = 'Uspesno izmenjen artikl'
          this.artiklService.dohvatiArtikleZaPreduzece(this.preduzece.pib).subscribe((data2:Array<Artikl>)=>{
            this.sviartikli=data2;
          })
        }
        else if(respObj['message']=='error'){
          this.message = 'greska'
        }
      })
      
      
    document.getElementById('mattabgrupa').style.display='none'
    
    document.getElementById('izmena').style.display='none'
  }
  
  obrisi(artikl){
    let dialogRef = this.dialog.open(RobeuslugedialogComponent, {
      width: '250px',
      data: { artikl:artikl,pib:this.preduzece.pib }
    });
    dialogRef.afterClosed().subscribe(result => {
      this.message = result;
      
      this.artiklService.dohvatiArtikleZaPreduzece(this.preduzece.pib).subscribe((data2:Array<Artikl>)=>{
        this.sviartikli=data2;
        this.dataSource=new MatTableDataSource(this.sviartikli)
        this.dataSource.paginator=this.paginator
      })
    });
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
