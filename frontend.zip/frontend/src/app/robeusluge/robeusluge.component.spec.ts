import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RobeuslugeComponent } from './robeusluge.component';

describe('RobeuslugeComponent', () => {
  let component: RobeuslugeComponent;
  let fixture: ComponentFixture<RobeuslugeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RobeuslugeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RobeuslugeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
