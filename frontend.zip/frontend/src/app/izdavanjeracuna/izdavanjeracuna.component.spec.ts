import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IzdavanjeracunaComponent } from './izdavanjeracuna.component';

describe('IzdavanjeracunaComponent', () => {
  let component: IzdavanjeracunaComponent;
  let fixture: ComponentFixture<IzdavanjeracunaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IzdavanjeracunaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IzdavanjeracunaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
