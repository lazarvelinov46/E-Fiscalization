import { Component, OnInit } from '@angular/core';
import { ArtiklService } from '../artikl.service';
import { Artikl } from '../model/artikl';
import { Magacin } from '../model/magacin';
import { Preduzece } from '../model/preduzece';
import { Racun } from '../model/racun';
import { RobaMagacin } from '../model/robamagacin';
import { PreduzeceService } from '../preduzece.service';
import { RacunService } from '../racun.service';
import { Stavka } from '../model/stavka';
import { OdeljenjeService } from '../odeljenje.service';
import { Odeljenje } from '../model/odeljenje';
import { StoService } from '../sto.service';
import { Zabranjeni } from '../model/zabranjeni';
import { Sto } from '../model/sto';
import { Narucilac } from '../model/narucilac';
import { NarucilacService } from '../narucilac.service';
import { Kasa } from '../model/kasa';
import { IzvestajService } from '../izvestaj.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-izdavanjeracuna',
  templateUrl: './izdavanjeracuna.component.html',
  styleUrls: ['./izdavanjeracuna.component.css']
})
export class IzdavanjeracunaComponent implements OnInit {

  constructor(private preduzeceService:PreduzeceService,private artiklService:ArtiklService,private racunService:RacunService,
    private odeljenjeService:OdeljenjeService,private stoService:StoService,private naruciociService:NarucilacService,
    private izvestajService:IzvestajService,private router:Router) { }

  ngOnInit(): void {
    
    this.pib=localStorage.getItem('pib')
    this.cena=0;
    this.porez=0;
    this.id=0;
    let vlasnik=JSON.parse(localStorage.getItem('ulogovan'))
    this.naruciociService.dohvatiNarucioce(vlasnik.username).subscribe((data:Narucilac[])=>{
      this.narucioci=data
    })
    this.preduzece=JSON.parse(localStorage.getItem('preduzece'))
      this.magacini=this.preduzece.magacini
      this.objekti=this.preduzece.kase
    
    this.artiklService.dohvatiArtikleZaPreduzece(this.pib).subscribe((data:Artikl[])=>{
      if(data){
        this.artikli=data;
      }
    })
    this.racunService.dohvatiRacune(this.pib).subscribe((data:Racun[])=>{
      if(data){
        this.id=data.length
        this.racuni=data
        this.racuni.forEach(rac => {
          if(rac.zatvoren==false){
            this.otvoreniRacuni.push(rac)
            if(rac.sto!=''){
            this.zauzeti.push(rac.sto)
            }
          }
        });
      }else{
        this.message='errrr'
      }
    })
    if(this.preduzece.kategorija=='ugostiteljski objekat'){
    this.odeljenjeService.dohvatiOdeljenja(this.pib,this.preduzece.kase[0].lokacija).subscribe((data:Odeljenje[])=>{
      if(data){
        this.odeljenja=data
      }
      this.promeniOdeljenje(this.odeljenja[0].naziv);
      this.message=this.trenutnoOdeljenje
    })
    //zatvaranje
  }
  }
  izobj:boolean;
  preduzece:Preduzece;
  pib:string;
  magacini:Array<Magacin>;
  artikli:Array<Artikl>=new Array<Artikl>();
  artikliPoMagacinu:Array<Artikl>=new Array<Artikl>();
  message:string;
  sifraZaUnos:string;
  kolicina:number
  cena:number
  porez:number
  artiklZaUnos:Artikl
  magacinZaUzeti:number
  racuni:Array<Racun>=new Array<Racun>();
  otvoreniRacuni:Array<Racun>=new Array<Racun>();
  odeljenje:string="";
  stoUnos:string="";
  stavke:Array<Stavka>=new Array<Stavka>();
  id:number;
  stavka:Stavka;
  objekti:Array<Kasa>=new Array<Kasa>();
  objekat:string;

//stolovi

odeljenja:Array<Odeljenje>=new Array<Odeljenje>()
trenutnoOdeljenje:string;
pozicijeStolova:Array<Zabranjeni>
stolovi:Array<Sto>=new Array<Sto>()
x:number;
y:number;
sto:Sto;
zauzeti:string[]=[]

  dodajSto(event){
    const canvas=document.getElementById("canv")as HTMLCanvasElement | null;
    // const rect = canvas.getBoundingClientRect()
    const rect = canvas.getBoundingClientRect()
    this.x = event.clientX - rect.left
    this.y = event.clientY - rect.top
    this.check()
  }
  promeniObjekat(){
    if(this.preduzece.kategorija=='ugostiteljski objekat'){
    this.odeljenjeService.dohvatiOdeljenja(this.pib,this.objekat).subscribe((data:Odeljenje[])=>{
      
        this.odeljenja=data
      this.promeniOdeljenje(this.odeljenja[0].naziv);
    })
  }
  }
  promeniOdeljenje(odeljenje){
    
    this.sto=null;
    this.trenutnoOdeljenje=odeljenje
    const canvas=document.getElementById("canv")as HTMLCanvasElement | null;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    this.stoService.dohvatiStolove(this.pib,this.objekat,odeljenje).subscribe((data2:Sto[])=>{
      if(data2){
        this.stolovi=data2
        this.pozicijeStolova=new Array<Zabranjeni>();
        let i=0
        this.stolovi.forEach(astal=>{
          if(astal.oblik=='krug'){
            this.pozicijeStolova[i]=new Zabranjeni()
            this.pozicijeStolova[i].naziv=astal.naziv
            this.pozicijeStolova[i].x=astal.x-astal.sirina          
            this.pozicijeStolova[i].y=astal.y-astal.visina
            this.pozicijeStolova[i].width=astal.sirina*2
            this.pozicijeStolova[i].height=astal.visina*2
            i++
          }else{
            this.pozicijeStolova[i]=new Zabranjeni()
            this.pozicijeStolova[i].naziv=astal.naziv
            this.pozicijeStolova[i].x=astal.x          
            this.pozicijeStolova[i].y=astal.y
            this.pozicijeStolova[i].width=astal.sirina
            this.pozicijeStolova[i].height=astal.visina
            i++
          }
          this.x=astal.x
          this.y=astal.y
          this.sto=astal
          this.iscrtajSto()
          this.sto=null
        })
      }
      
    })
  }
  iscrtajSto(){
    const canvas=document.getElementById("canv")as HTMLCanvasElement | null;
    const ctx = canvas.getContext('2d');
    
    if(this.sto.oblik=='krug'){
      ctx.beginPath();
      ctx.arc(this.x,this.y,this.sto.sirina,0,2*Math.PI)
      ctx.fillStyle="#04AA6D"
      ctx.fill();
      ctx.stroke();
      ctx.strokeText(this.sto.naziv,this.x,this.y)
      this.zauzeti.forEach(element => {
        if(this.sto.naziv==element){
          
          ctx.beginPath();
          ctx.arc(this.x,this.y,this.sto.sirina,0,2*Math.PI)
          ctx.fillStyle="#04AA6D"
          ctx.fill();
          ctx.stroke();
          ctx.strokeText("zauzet",this.x-this.sto.sirina,this.y)
        }
      });
    }else{
      ctx.fillStyle="#04AA6D"
      ctx.fillRect(this.x,this.y,this.sto.sirina,this.sto.visina)
      ctx.strokeRect(this.x,this.y,this.sto.sirina,this.sto.visina)
    ctx.strokeText(this.sto.naziv,this.x+this.sto.sirina/2,this.y+this.sto.visina/2)
    this.zauzeti.forEach(element => {
      if(this.sto.naziv==element){
        ctx.fillStyle="#04AA6D"
        ctx.fillRect(this.x,this.y,this.sto.sirina,this.sto.visina)
        
      ctx.strokeRect(this.x,this.y,this.sto.sirina,this.sto.visina)
        ctx.strokeText("zauzet",this.x,this.y+this.sto.visina/2)
      }
    });
    }
  }
  check(){
    let moze=true
    this.pozicijeStolova.forEach(z => {
      if(this.x>z.x&&this.x<z.x+z.width){
        if(this.y>z.y&&this.y<z.y+z.height){
          this.zauzeti.forEach(zauz => {
            if(z.naziv==zauz){
              moze=false
            }
          });
          if(moze){
            this.odeljenje=this.trenutnoOdeljenje
            this.stoUnos=z.naziv
          }
        }
      }
    });
  }
  //kraj stolovi
  dodaj(){
    if(this.preduzece.kategorija=='ugostiteljski objekat'){
    let ima=false
    this.zauzeti.forEach(z => {
      if(z==this.stoUnos){
        ima=true;
      }
    });
    if(this.stoUnos!=''&&!ima){
      
      this.zauzeti.push(this.stoUnos)
    }
  }
    let cenaTrenutna=0
    let porezTrenutni=0
    this.artikli.forEach(art=>{
      if(art.sifra==this.sifraZaUnos){
        this.artiklZaUnos=art
      }
    })
    let stavka=new Stavka()
    stavka.naziv=this.artiklZaUnos.naziv
    stavka.jedinicaMere=this.artiklZaUnos.jedinicaMere
    stavka.kolicina=this.kolicina
    if(this.izobj){
      for(let i=0;i<this.artiklZaUnos.robaobjekat.length;i++){
        if(this.artiklZaUnos.robaobjekat[i].objekat==this.objekat){
          if(this.artiklZaUnos.robaobjekat[i].tekuceStanje-this.kolicina>=0){
          cenaTrenutna+=this.artiklZaUnos.robaobjekat[i].prodajnaCena*this.kolicina
          stavka.cena=this.artiklZaUnos.robaobjekat[i].prodajnaCena
          this.artiklZaUnos.robaobjekat[i].tekuceStanje-=this.kolicina
          }else{
            alert('Nema toliko proizvoda na lageru')
            this.kolicina=0
            return;
          }
        }
      }
    }else{
      for(let i=0;i<this.artiklZaUnos.robamagacin.length;i++){
        if(this.artiklZaUnos.robamagacin[i].idMagacin==this.magacinZaUzeti){
          if(this.artiklZaUnos.robamagacin[i].tekuceStanje-this.kolicina>=0){
          cenaTrenutna+=this.artiklZaUnos.robamagacin[i].prodajnaCena*this.kolicina
          stavka.cena=this.artiklZaUnos.robamagacin[i].prodajnaCena
          this.artiklZaUnos.robamagacin[i].tekuceStanje-=this.kolicina
          }else{
            alert('Nema toliko proizvoda na lageru')
            this.kolicina=0
            return;
          }
        }
      }
    }
    
    this.stavke.push(stavka)
    porezTrenutni=cenaTrenutna*this.artiklZaUnos.poreskaStopa/100
    this.cena+=cenaTrenutna
    this.porez+=porezTrenutni
    if(this.izobj){
      this.artiklService.smanjiObjekat(this.pib,this.artiklZaUnos.sifra,this.artiklZaUnos.robaobjekat).subscribe(respObj2=>{
        if(respObj2['message']=='ok'){
          
          
          this.message='Dodata stavka na racun'
        }else{
          this.message='error'
        }
      })
    }else{
      this.artiklService.smanjiMagacin(this.pib,this.artiklZaUnos.sifra,this.artiklZaUnos.robamagacin).subscribe(respObj2=>{
        if(respObj2['message']=='ok'){
          
          
          this.message='Dodata stavka na racun'
        }else{
          this.message='error'
        }
      })
   }
    this.kolicina=0
    if(this.preduzece.kategorija=='ugostiteljski objekat'){
    this.promeniOdeljenje(this.trenutnoOdeljenje)
    }
  }
  noviRacun(){
    let racun=new Racun()
    racun.pib=this.pib
    racun.idp=this.id
    racun.preduzece=this.preduzece.naziv
    racun.stavke=this.stavke
    racun.cena=this.cena
    racun.porez=this.porez
    racun.odeljenje=this.odeljenje
    racun.sto=this.stoUnos
    this.otvoreniRacuni.push(racun)
    this.racunService.unesiRacun(this.pib,this.id,this.preduzece.naziv,this.objekat,this.stavke,this.cena,this.porez,this.odeljenje,this.stoUnos).subscribe(respObj=>{
      if(respObj['message']=='ok'){
            this.stavke=new Array<Stavka>()
            this.cena=0
            this.porez=0
            this.id++;
            this.odeljenje="";
            this.stoUnos=""
            if(this.preduzece.kategorija=='ugostiteljski objekat'){
            this.promeniOdeljenje(this.trenutnoOdeljenje)
            }
      }else{
        this.message='error'
      }
     })
  }
  //zatvaranja
  nacinPlacanja:string
  racunZaZatvaranje:Racun=new Racun()
  vrednost:number;
  racunid:number;
  lk:string;
  ime:string;
  prezime:string;
  slipRacun:string;
  narucilac:Narucilac;
  narucioci:Array<Narucilac>=new Array<Narucilac>()
  potvrdiOdabir(){
    this.message=this.racunid.toString()
    this.otvoreniRacuni.forEach(element => {
      if(element.idp==this.racunid){
        this.racunZaZatvaranje=element
      }
    });
    if(this.nacinPlacanja=='gotovina'){
      document.getElementById('gotovina').style.display='block'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='none'
    }else if(this.nacinPlacanja=='cek'){
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='block'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='none'

    }else if (this.nacinPlacanja=='kartica'){
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='block'
      document.getElementById('virman').style.display='none'

    }else if (this.nacinPlacanja=='virman'){
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='block'

    }
  }
  zatvoriGotovina(){    
    let datum=new Date().toDateString()
    if(this.vrednost>=this.racunZaZatvaranje.cena){
      let kusur=this.vrednost-this.racunZaZatvaranje.cena
      this.racunService.zatvoriGotovina(this.pib,this.racunid,this.vrednost,kusur,this.lk,datum).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.izvestajService.unesiIzvestaj(this.pib,this.preduzece.naziv,this.racunZaZatvaranje.cena,
            this.racunZaZatvaranje.porez,datum).subscribe(respObj=>{
              if(respObj['message']=='err'){
                alert('error')
              }
            })
          let i
          this.otvoreniRacuni.forEach((element,index)=>{
            if(element.idp==this.racunid) i=index;
          });
          this.otvoreniRacuni.splice(i,1)
          this.racunid=-1
          
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='none'
          this.zauzeti.forEach((element,index)=>{
            if(element==this.racunZaZatvaranje.sto) this.zauzeti.splice(index,1);
          });
          //this.promeniOdeljenje(this.odeljenja[0].naziv)
        }
      })
    }else{
      alert("Nedovoljno novca")
    }
  }
  zatvoriCek(){
    let datum=new Date().toDateString()
    this.racunService.zatvoriCek(this.pib,this.racunid,this.ime,this.prezime,this.lk,datum).subscribe(respObj=>{
      if(respObj['message']=='ok'){
        this.izvestajService.unesiIzvestaj(this.pib,this.preduzece.naziv,this.racunZaZatvaranje.cena,
          this.racunZaZatvaranje.porez,datum).subscribe(respObj=>{
            if(respObj['message']=='err'){
              alert('error')
            }
          })
        let i
        this.otvoreniRacuni.forEach((element,index)=>{
          if(element.idp==this.racunid) i=index;
        });
        
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='none'
        this.otvoreniRacuni.splice(i,1)
        this.racunid=-1
        this.zauzeti.forEach((element,index)=>{
          if(element==this.racunZaZatvaranje.sto) this.zauzeti.splice(index,1);
        });
        
        //this.promeniOdeljenje(this.odeljenja[0].naziv)
      }
    })
  }
  zatvoriKarticu(){
    let datum=new Date().toDateString()
    this.racunService.zatvoriKartica(this.pib,this.racunid,this.lk,this.slipRacun,datum).subscribe(respObj=>{
      if(respObj['message']=='ok'){
        this.izvestajService.unesiIzvestaj(this.pib,this.preduzece.naziv,this.racunZaZatvaranje.cena,
          this.racunZaZatvaranje.porez,datum).subscribe(respObj=>{
            if(respObj['message']=='err'){
              alert('error')
            }
          })
        let i
        this.otvoreniRacuni.forEach((element,index)=>{
          if(element.idp==this.racunid) i=index;
        });
        this.otvoreniRacuni.splice(i,1)
        this.racunid=-1
        
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='none'
        this.zauzeti.forEach((element,index)=>{
          if(element==this.racunZaZatvaranje.sto) this.zauzeti.splice(index,1);
        });
        
        //this.promeniOdeljenje(this.odeljenja[0].naziv)
      }
    })
  }
  zatvoriVirman(){
    let datum=new Date().toDateString()
    this.racunService.zatvoriVirman(this.pib,this.racunid,this.narucilac,datum).subscribe(respObj=>{
      if(respObj['message']=='ok'){
        this.izvestajService.unesiIzvestaj(this.pib,this.preduzece.naziv,this.racunZaZatvaranje.cena,
          this.racunZaZatvaranje.porez,datum).subscribe(respObj=>{
            if(respObj['message']=='error'){
              alert('error')
            }
          })
        let i
        
      document.getElementById('gotovina').style.display='none'
      document.getElementById('cek').style.display='none'
      document.getElementById('kartica').style.display='none'
      document.getElementById('virman').style.display='none'
        this.otvoreniRacuni.forEach((element,index)=>{
          if(element.idp==this.racunid) i=index;
        });
        this.otvoreniRacuni.splice(i,1)
        this.racunid=-1
        this.zauzeti.forEach((element,index)=>{
          if(element==this.racunZaZatvaranje.sto) this.zauzeti.splice(index,1);
        });
        
        //this.promeniOdeljenje(this.odeljenja[0].naziv)
      }
    })
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
