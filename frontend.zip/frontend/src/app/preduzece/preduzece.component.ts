import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Banka } from '../model/banka';
import { Kasa } from '../model/kasa';
import { Korisnik } from '../model/korisnik';
import { Magacin } from '../model/magacin';
import { Preduzece } from '../model/preduzece';
import { PreduzeceService } from '../preduzece.service';

@Component({
  selector: 'app-preduzece',
  templateUrl: './preduzece.component.html',
  styleUrls: ['./preduzece.component.css']
})
export class PreduzeceComponent implements OnInit {

  constructor(private preduzeceService:PreduzeceService,private router:Router) { }
message:string
  ngOnInit(): void {
    this.prikaz=true
    this.sifrarnik=["kafic","market","kafana","trafika"];
    this.modelikase=["samsung","apple","Ei nis"];
    this.vlasnik=JSON.parse(localStorage.getItem('ulogovan'))
    this.preduzeceService.dohvatiPreduzece(this.vlasnik.username).subscribe((data:Preduzece)=>{
      
      this.preduzece=data;
      this.brMag=this.preduzece.magacini.length;
      this.brKas=this.preduzece.kase.length;
      this.stariBrojKasa=this.brKas;
      this.stariBrojMagacina=this.brMag
      localStorage.setItem('pib',data.pib);
      localStorage.setItem('preduzece',JSON.stringify(this.preduzece));
    })
  }
  trackByIndex(index: number, obj: any): any {
    return index;
  }
  vlasnik:Korisnik
  preduzece:Preduzece=new Preduzece()
  sifrarnik:Array<String>=[]
  modelikase:Array<String>=[]
  banka:string;
  racun:string;
  brMag:number;
  brKas:number;
  stariBrojMagacina;
  stariBrojKasa;
  prikaz:boolean=true
  message2:string
  
  emailIzraz=new RegExp("^[a-z][a-z0-9]*@[a-z]+\\.[a-z]+$");
  racunIzraz = new RegExp("^[0-9]{3}\\-[0-9]{12}\\-[0-9]{2}$");
  ukloniRacun(rac){
    this.preduzece.racuni.forEach((element,index)=>{
      if(element.racun==rac) this.preduzece.racuni.splice(index,1);
   });
  }
  dodajRacun(){
    if(this.racunIzraz.test(this.racun)==false){
    this.message2="Bankovni racun nije u odgovarajucem obliku!!!"
    return;
  }
  let b=new Banka()
  b.banka=this.banka
  b.racun=this.racun
  this.preduzece.racuni.push(b)
  this.message2="Uspesno dodata banka"
  document.getElementById('ban').ariaValueText=""
  
  document.getElementById('ziro').ariaValueText=""
  this.banka="";
  this.racun="";
  }
  potvrdiBrojKasa(){
    
    if(this.brKas>this.preduzece.kase.length){
      for(let i=this.preduzece.kase.length;i<this.brKas;i++){
        this.preduzece.kase[i]=new Kasa();
      }
    }else{
      this.message="Ne moze se unositi manje kasa"
    }
    
  }
  potvrdiBrojMagacina(){
    if(this.brMag>this.preduzece.magacini.length){
      for(let i=this.preduzece.magacini.length;i<this.brMag;i++){
        this.preduzece.magacini[i]=new Magacin();
      }
    }else{
      this.message="Ne moze se unositi manje magacina"
    }
  }
  spremiIzmenu(){
    this.prikaz=false;
  }
  izmeni(){
    if(this.emailIzraz.test(this.vlasnik.email)==false){
      this.message="Email nije u odgovarajucem obliku!!!"
      return;
    }
    for(let i=0;i<this.preduzece.magacini.length;i++){
      for(let j=0;j<this.preduzece.magacini.length;j++){
        if(j!=i){
          if(this.preduzece.magacini[i].id==this.preduzece.magacini[j].id){
            this.message="Imate 2 magacina sa istim id-jem"
            return;
          }
        }
      }
    }
    if(this.vlasnik.ime==''||this.vlasnik.prezime==''||this.vlasnik.telefon==''||this.vlasnik.email==''||
    this.preduzece.naziv==''||this.preduzece.adresa==''||this.preduzece.sifraDelatnosti.length==0||this.preduzece.racuni.length==0||
    this.preduzece.magacini.length==0||this.preduzece.kase.length==0){
      alert("Nisu uneta sva polja")
      return;
    }
    this.preduzeceService.apdejtuj(this.vlasnik.username,this.vlasnik.ime,this.vlasnik.prezime,this.vlasnik.telefon,
      this.vlasnik.email,this.preduzece.naziv,this.preduzece.adresa,this.preduzece.kategorija,this.preduzece.sifraDelatnosti,
      this.preduzece.pdv,this.preduzece.racuni,this.preduzece.magacini,this.preduzece.kase).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.preduzeceService.dohvatiPreduzece(this.vlasnik.username).subscribe((data:Preduzece)=>{
            localStorage.clear()
            this.message=''
            this.message2=''
            this.prikaz=true
            this.preduzece=data;
            this.brMag=this.preduzece.magacini.length;
            this.brKas=this.preduzece.kase.length;
            localStorage.setItem('pib',data.pib);
            localStorage.setItem('preduzece',JSON.stringify(this.preduzece));
            localStorage.setItem('ulogovan',JSON.stringify(this.vlasnik))
          })

        }
      })
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
