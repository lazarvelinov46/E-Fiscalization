import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Korisnik } from '../model/korisnik';
import { Preduzece } from '../model/preduzece';
import { Racun } from '../model/racun';
import { PreduzeceService } from '../preduzece.service';
import { RacunService } from '../racun.service';

@Component({
  selector: 'app-pregledracuna',
  templateUrl: './pregledracuna.component.html',
  styleUrls: ['./pregledracuna.component.css']
})
export class PregledracunaComponent implements OnInit {

  constructor(private racunService:RacunService,private preduzeceService:PreduzeceService,private router:Router) { }

  ngOnInit(): void {
    this.korisnik=JSON.parse(localStorage.getItem('ulogovan'))
    this.racunService.dohvatiLicna(this.korisnik.licna_karta).subscribe((data:Racun[])=>{
      if(data){
        this.racuni=data
        this.racuni.forEach(rac => {
          let dt=new Date(rac.datum).toDateString()
          rac.datum=dt
        });
      }
    })
  }

racuni:Array<Racun>=new Array<Racun>()
korisnik:Korisnik
detaljanRacun:Racun=null;
detalji:boolean=false;
uo:boolean;
detaljanPrikaz(r){
  this.detaljanRacun=r;
  this.detalji=true
  this.preduzeceService.dohvatiPoPib(this.detaljanRacun.pib).subscribe((data:Preduzece)=>{
    if(data.kategorija=='ugostiteljski objekat'){
      this.uo=true;
    }else{
      this.uo=false;
    }
  })
}
logout(){
  sessionStorage.clear()
  localStorage.clear()
  this.router.navigate([''])
}
}
