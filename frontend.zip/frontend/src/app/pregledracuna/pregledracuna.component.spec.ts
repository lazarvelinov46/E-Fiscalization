import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PregledracunaComponent } from './pregledracuna.component';

describe('PregledracunaComponent', () => {
  let component: PregledracunaComponent;
  let fixture: ComponentFixture<PregledracunaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PregledracunaComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PregledracunaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
