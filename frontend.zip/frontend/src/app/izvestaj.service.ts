import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class IzvestajService {
  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

  unesiIzvestaj(pib,preduzece,iznos,porez,datum){
    const data = {
      pib: pib,
      preduzece: preduzece,
      iznos:iznos,
      porez:porez,
      datum:datum
    }

    return this.http.post(`${this.uri}/izvestaj/unesiizvestaj`, data)
  }
  dohvatiPib(pib){
    
    return this.http.get(`${this.uri}/izvestaj/dohvatipib?param=${pib}`)
  }
  dohvatiPreduzece(preduzece){
    
    return this.http.get(`${this.uri}/izvestaj/dohvatipreduzece?param=${preduzece}`)
  }
  dohvati(){
    

    return this.http.get(`${this.uri}/izvestaj/dohvati`)
  }
}
