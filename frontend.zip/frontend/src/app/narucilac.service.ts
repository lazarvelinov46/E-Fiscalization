import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NarucilacService {

  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

  unesiNarucioca(vlasnik, narucilacPib,brojDana,procenatRabata){
    const data = {
      vlasnik: vlasnik,
      narucilacPib: narucilacPib,
      brojDana:brojDana,
      procenatRabata:procenatRabata
    }

    return this.http.post(`${this.uri}/narucioci/unesi`, data)
  }
  dohvatiNarucioce(vlasnik){
    

    return this.http.get(`${this.uri}/narucioci/dohvati?param=${vlasnik}`)
  }
}
