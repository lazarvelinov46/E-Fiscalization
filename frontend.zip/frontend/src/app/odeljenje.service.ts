import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OdeljenjeService {

  constructor(private http:HttpClient) { }

  uri = 'http://localhost:4000'

  unesiOdeljenje(pib,objekat, naziv){
    const data = {
      pib: pib,
      objekat:objekat,
      naziv: naziv
    }

    return this.http.post(`${this.uri}/odeljenja/unesi`, data)
  }
  dohvatiOdeljenja(pib,objekat){
    const data={
      pib:pib,
      objekat:objekat
    }

    return this.http.post(`${this.uri}/odeljenja/dohvati`,data)
  }
}
