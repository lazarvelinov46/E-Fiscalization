import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RobeuslugedialogComponent } from './robeuslugedialog.component';

describe('RobeuslugedialogComponent', () => {
  let component: RobeuslugedialogComponent;
  let fixture: ComponentFixture<RobeuslugedialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RobeuslugedialogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RobeuslugedialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
