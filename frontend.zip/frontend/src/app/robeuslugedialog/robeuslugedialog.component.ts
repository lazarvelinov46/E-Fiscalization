import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ArtiklService } from '../artikl.service';
import { Artikl } from '../model/artikl';

@Component({
  selector: 'app-robeuslugedialog',
  templateUrl: './robeuslugedialog.component.html',
  styleUrls: ['./robeuslugedialog.component.css']
})
export class RobeuslugedialogComponent implements OnInit {

  constructor(
    public dialogRef: MatDialogRef<RobeuslugedialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,private artiklService:ArtiklService) { }

  ngOnInit(): void {
    
  }
  artikl:Artikl;
  pib:string;
  message:string;
  brisi(){
    this.artikl=this.data.artikl;
    this.pib=this.data.pib;
    this.artiklService.obrisiArtikl(this.pib,this.artikl.sifra).subscribe(respObj=>{
      this.message=respObj['message']
      
      this.dialogRef.close(this.message);
    })
  }

  close(){
    this.dialogRef.close();
  }

}
