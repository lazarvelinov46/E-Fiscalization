import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IzvestajService } from '../izvestaj.service';
import { KorisnikService } from '../korisnik.service';
import { Banka } from '../model/banka';
import { Izvestaj } from '../model/izvestaj';
import { Kasa } from '../model/kasa';
import { Magacin } from '../model/magacin';
import { Preduzece } from '../model/preduzece';
import { PreduzeceService } from '../preduzece.service';

@Component({
  selector: 'app-administrator',
  templateUrl: './administrator.component.html',
  styleUrls: ['./administrator.component.css']
})
export class AdministratorComponent implements OnInit {

  constructor(private korisnikService:KorisnikService,private preduzeceService:PreduzeceService,
    private izvestajService:IzvestajService,private router:Router) { }

  ngOnInit(): void {
    this.preduzeceService.dohvatiPreduzeca().subscribe((data:Preduzece[])=>{
      this.preduzeca=data;
    })
    this.sifrarnik=["kafic","market","kafana","trafika"];
    
    this.modelikase=["samsung","apple","Ei nis"];
  }

  //aktivacija i deaktivacija preduzeca
  preduzeca:Preduzece [];
  messageaktivacija:string;
  aktiviraj(pib){
    
    this.preduzeceService.aktiviraj(pib).subscribe((res)=>{
      if(res['message']!='ok'){
        this.messageaktivacija='Greska'
      }else{
        this.preduzeca.forEach(p => {
          if(p.pib==pib){
            p.status='aktivan'
          }
        });
      }
    })

  }
  deaktiviraj(pib){
    
    this.preduzeceService.deaktiviraj(pib).subscribe((res)=>{
      if(res['message']!='ok'){
        this.messageaktivacija='Greska'
      }else{
        this.preduzeca.forEach(p => {
          if(p.pib==pib){
            p.status='neaktivan'
          }
        });
      }
    })

  }

  sifraIzraz = new RegExp("^[A-Za-z](?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{7,11}$");
  pibIzraz=new RegExp("^[1-9][0-9]{8}$");
  emailIzraz=new RegExp("^[a-z][a-z0-9]*@[a-z]+\\.[a-z]+$");

  //za kupca
  imeKupca:string='';
  prezimeKupca:string='';
  usernameKupca:string='';
  passwordKupca:string='';
  passwordKupca2:string='';
  telefonKupca:string='';
  licna:string='';
  messagekupac:string='';

  dodajKupca(){
    if(this.sifraIzraz.test(this.passwordKupca)==false){
      this.messagekupac="Sifra nije u ispravnom formatu!!!"
      return;
    }
    if(this.imeKupca==''||this.prezimeKupca==''||this.usernameKupca==''||this.telefonKupca==''||this.licna==''){
      this.messagekupac="Nisu uneti svi podaci"
      return;
    }
    if(this.passwordKupca!=this.passwordKupca2){
      this.messagekupac="Razlicite lozinke";
    }else{
      this.korisnikService.dodajKupca(this.imeKupca,this.prezimeKupca,this.usernameKupca,this.passwordKupca,this.telefonKupca,
        this.licna).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.messagekupac = 'Dodat kupac'
        }
        else{
          this.messagekupac = respObj['message']
        }
      })
    }
  }
//registracija preduzeca
imeReg:string;
  prezimeReg:string;
  usernameReg:string;
  passwordReg:string;
  passwordReg2:string;
  kontaktTel:string;
  email:string;
  naziv:string;
  adresa:string;
  pib:string;
  matbroj:string;
  message1:string;
  sifrarnik:string[]
  modelikase:string[]
  kategorija:string
  sifre:string[]=[]
  pdv:boolean
  banka:string=""
  racun:string=""
  banke:Array<Banka>=[]
  brMag:number=1
  magacini:Array<Magacin>
  brojKasa:number=1
  kase:Array<Kasa>
  messagerr:string
  slika:any;

  racunIzraz = new RegExp("^[0-9]{3}\\-[0-9]{12}\\-[0-9]{2}$");

  trackByIndex(index: number, obj: any): any {
    return index;
  }
  dodajBanku(){
    if(this.racunIzraz.test(this.racun)==false){
      this.messagerr="Bankovni racun nije u odgovarajucem obliku!!!"
      return;
    }
    let b=new Banka()
    b.banka=this.banka
    b.racun=this.racun
    this.banke.push(b)
    document.getElementById('ban').ariaValueText=""
    
    document.getElementById('ziro').ariaValueText=""
    this.banka="";
    this.racun="";
  }

  potvrdiBrojMagacina(){
    this.magacini=[]
    for(let i=0;i<this.brMag;i++){

      this.magacini[i]=new Magacin()
      
    }
    
  }
  potvrdiBrojKasa(){
    this.kase=[]
    for(let i=0;i<this.brojKasa;i++){

      this.kase[i]=new Kasa()
    }
    
  }
  odaberiSliku(event: any){
    if(!event.target.files[0]||event.target.files[0].length==0){
      this.messagerr="Nije uneta nijedna slika";
      return;
    }
    let tip=event.target.files[0].type;
    if(tip.match(/image\/*/)==null){
      this.messagerr="Tip nije slika";
      return;
    }
    let citac=new FileReader();
    citac.readAsDataURL(event.target.files[0]);

    citac.onload=(_event)=>{
      let slika=new Image();
      slika.onload=(event_slika:any)=>{
        if(slika.width>300 || slika.width<100||slika.height>300||slika.height<100){
          this.messagerr="Velicina slike nije u opsegu od 100x100 do 300x300"
        }
      }
      this.slika=_event.target.result;
    }
    
  }
  register(){
    if(this.sifraIzraz.test(this.passwordReg)==false){
      this.messagerr="Sifra nije u odgovarajucem obliku!!!"
      return;
    }
    if(this.emailIzraz.test(this.email)==false){
      this.messagerr="Email nije u odgovarajucem obliku!!!"
      return;
    }
    if(this.pibIzraz.test(this.pib)==false){
      this.messagerr="PIB nije u odgovarajucem obliku!!!"
      return;
    }
    for(let i=0;i<this.magacini.length;i++){
      for(let j=0;j<this.magacini.length;j++){
        if(j!=i){
          if(this.magacini[i].id==this.magacini[j].id){
            this.messagerr="Imate 2 magacina sa istim id-jem"
            return;
          }
        }
      }
    }
    if(this.imeReg==''||this.prezimeReg==''||this.usernameReg==''||this.kontaktTel==''||this.email==''||this.naziv==''||
      this.adresa==''||this.pib==''||this.matbroj==''||this.sifre.length==0||this.banke.length==0||this.magacini.length==0||this.kase.length==0){
        this.messagerr="Nisu uneti svi podaci pri registraciji"
        return;
      }
    if(this.passwordReg!=this.passwordReg2){
      this.messagerr="Nisu iste sifre!!!"
    }else{
      this.preduzeceService.register(this.imeReg,this.prezimeReg,this.usernameReg,this.passwordReg,this.kontaktTel,
        this.email,this.naziv,this.adresa,this.pib,this.matbroj,true,this.slika).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.preduzeceService.zavrsiRegistraciju(this.usernameReg,this.kategorija,this.sifre,this.pdv,this.banke,this.magacini,this.kase).subscribe(respObj=>{
            if(respObj['message']=='err kategorija'){
              
            }
            else{
            }
          })
        }
        else{
          this.messagerr = respObj['message']
        }
      })
            
    
  }
    
  }
//izvestaji
filter:string;
paramPretrage:string;
datumOd:Date;
datumDo:Date;
izvestaji:Array<Izvestaj>=new Array<Izvestaj>()
dohvatiIzvestaje(){
  this.izvestaji=new Array<Izvestaj>()
  let datodstr=new Date(this.datumOd)
  let datdostr=new Date(this.datumDo)
  let iztemp=new  Array<Izvestaj>()
  if(this.filter=='pib'){
    this.izvestajService.dohvatiPib(this.paramPretrage).subscribe((data:Izvestaj[])=>{
      if(data){
        data.forEach(iz => {
          let diz=new Date(iz.datum)
          if(diz.getTime()>=datodstr.getTime()&&diz.getTime()<=datdostr.getTime()){
            this.izvestaji.push(iz);
          }
        });
      }
    })
  }else if(this.filter=='naziv'){
    this.izvestajService.dohvatiPreduzece(this.paramPretrage).subscribe((data:Izvestaj[])=>{
      if(data){
        data.forEach(iz => {
          let diz=new Date(iz.datum)
          if(diz.getTime()>=datodstr.getTime()&&diz.getTime()<=datdostr.getTime()){
            this.izvestaji.push(iz);
          }
        });
      }
    })
  }else{
    this.izvestajService.dohvati().subscribe((data:Izvestaj[])=>{
      if(data){
        data.forEach(iz => {
          let diz=new Date(iz.datum)
          if(diz.getTime()>=datodstr.getTime()&&diz.getTime()<=datdostr.getTime()){
            this.izvestaji.push(iz);
          }
        });
      }
    })
  }
}
logout(){
  
  sessionStorage.clear()
  localStorage.clear()
  this.router.navigate([''])
}
}
