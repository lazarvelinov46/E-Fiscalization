export class Narucilac{
    vlasnik:string;
    narucilacPib:string;
    brojDana:number;
    procenatRabata:number;
}