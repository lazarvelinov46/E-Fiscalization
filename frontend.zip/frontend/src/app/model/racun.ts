import { Artikl } from "./artikl"
import { Narucilac } from "./narucilac";
import { Stavka } from "./stavka";

export class Racun{
    pib:string;
    idp:number;
    preduzece:string;
    objekat:string;
    stavke:Array<Stavka>;
    cena:number;
    porez:number;
    odeljenje:string;
    sto:string;
    zatvoren:boolean;
    nacinPlacanja:string;
    placeno:number;
    kusur:number;
    licnaKarta:string;
    ime:string;
    prezime:string;
    brojRacuna:string;
    narucioc:Narucilac;
    datum:string;
}