import { RobaMagacin } from "./robamagacin"

export class ObjekatRM{
    objekat:string
    robeimagacini:Array<RobaMagacin>
}