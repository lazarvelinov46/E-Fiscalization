export class Stavka{
    naziv:string;
    jedinicaMere:string;
    kolicina:number;
    cena:number;
}