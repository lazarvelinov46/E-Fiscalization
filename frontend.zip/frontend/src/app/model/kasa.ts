export class Kasa{
    lokacija:string;
    modelKase:string;
}