export class Izvestaj{
    pib:string;
    preduzece:string;
    iznos:number;
    porez:number;
    datum:string;
}
