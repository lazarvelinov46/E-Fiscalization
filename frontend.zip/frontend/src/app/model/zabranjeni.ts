export class Zabranjeni{
    naziv:string;
    x:number;
    y:number;
    width:number;
    height:number;
}