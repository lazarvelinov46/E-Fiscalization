import { Magacin } from "./magacin";

export class RobaMagacin{
    idMagacin:number;
    nazivMagacin:string;
    nabavnaCena:number;
    prodajnaCena:number;
    tekuceStanje:number;
    minZeljenaKolicina:number;
    maxZeljenaKolicina:number;
}