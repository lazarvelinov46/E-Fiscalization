export class Korisnik{
    username: string;
    password: string;
    vrsta:string;
    ime: string;
    prezime: string;
    telefon:string;
    licna_karta:string;
    email:string;
    prviPut:boolean;
}