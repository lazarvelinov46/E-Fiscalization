import { Artikl } from "./artikl";

export class Kategorija{
    pib:string;
    naziv:string;
    potkategorije:Array<string>;
}