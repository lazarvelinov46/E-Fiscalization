export class Odeljenje{
    pib:string;
    objekat:string;
    naziv:string;
}