export class Sto{
    pib:string;
    objekat:string;
    odeljenje:string;
    naziv:string;
    oblik:string;
    sirina:number;
    visina:number;
    x:number;
    y:number;
}