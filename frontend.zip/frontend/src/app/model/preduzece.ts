import { Banka } from "./banka";
import { Kasa } from "./kasa";
import { Magacin } from "./magacin";

export class Preduzece{
    vlasnik:string;
    naziv:string;
    adresa:string;
    pib:string;
    matbroj:string;
    slika:any;
    status:string;
    kategorija:string;
    sifraDelatnosti:Array<string>;
    pdv:boolean;
    racuni:Array<Banka>;
    magacini:Array<Magacin>;
    kase:Array<Kasa>;
}