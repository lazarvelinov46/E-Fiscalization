export class Banka{
    banka:string;
    racun:string;
}