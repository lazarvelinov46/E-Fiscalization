export class Magacin{
    id:number;
    naziv:string;
}