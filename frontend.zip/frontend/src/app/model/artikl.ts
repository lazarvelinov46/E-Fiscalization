import { RobaMagacin } from "./robamagacin";
import { RobaObjekat } from "./robaobjekat";

export class Artikl{
    pib:string;
    sifra:string;
    naziv:string;
    jedinicaMere:string;
    poreskaStopa:number;
    vrsta:string;
    zemljaPorekla:string;
    straniNaziv:string;
    barkod:string;
    proizvodjac:string;
    carinskaTarifa:number;
    ekoTaksa:boolean;
    akcize:boolean;
    minZalihe:number;
    maxZalihe:number;
    opis:string;
    deklaracija:string;
    slika:any;
    robamagacin:Array<RobaMagacin>;
    robaobjekat:Array<RobaObjekat>;
    kategorija:string;
    potkategorija:string;
}