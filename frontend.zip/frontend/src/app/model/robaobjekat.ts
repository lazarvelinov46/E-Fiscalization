export class RobaObjekat{
    objekat:string;
    nabavnaCena:number;
    prodajnaCena:number;
    tekuceStanje:number;
    minZeljenaKolicina:number;
    maxZeljenaKolicina:number;
}