import { EOF } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ArtiklService } from '../artikl.service';
import { Artikl } from '../model/artikl';
import { Preduzece } from '../model/preduzece';
import { PreduzeceService } from '../preduzece.service';

@Component({
  selector: 'app-kupac',
  templateUrl: './kupac.component.html',
  styleUrls: ['./kupac.component.css']
})
export class KupacComponent implements OnInit {

  constructor(private router:Router,private preduzeceService:PreduzeceService,private artiklService:ArtiklService) { }

  ngOnInit(): void {
    this.preduzeceService.dohvatiPreduzeca().subscribe((data:Preduzece[])=>{
      if(data){
        this.preduzeca=data
      }
    })
    this.artiklService.dohvatiCeluBazu().subscribe((data2:Artikl[])=>{
      if(data2){
        this.artikli=data2
      }
    })
  }

  change(){
    this.router.navigate(['changepassword']);
  }
  trackByIndex(index: number, obj: any): any {
    return index;
  }
  najmanjeCene:Array<number>=new Array<number>()
  preduzeca:Array<Preduzece>=new Array<Preduzece>()
  artikli:Array<Artikl>=new Array<Artikl>()
  artikliPrikaz:Array<Artikl>=new Array<Artikl>()
  prikaziArtikle(p){
    this.artiklService.dohvatiArtikleZaPreduzece(p).subscribe((data:Artikl[])=>{
      if(data){
        this.artikliPrikaz=data;
        for(let i=0;i<this.artikliPrikaz.length;i++){
          this.najmanjeCene[i]=Number.MAX_SAFE_INTEGER
          this.artikliPrikaz[i].robaobjekat.forEach(ro => {
            if(ro.prodajnaCena<this.najmanjeCene[i]){
              this.najmanjeCene[i]=ro.prodajnaCena
            }
          });
        }
      }
    })
  }
  //ptretraga
  zaPretragu:string;
  nacin:string;
  najmanjeCenePretraga:Array<Number>=new Array<Number>()
  artikliPretraga:Array<Artikl>=new Array<Artikl>()
  pretraga(){
    if(this.nacin=='naziv'){
      this.artiklService.pretragaNaziv(this.zaPretragu).subscribe((data:Artikl[])=>{
        if(data){
          this.artikliPretraga=data;
        for(let i=0;i<this.artikliPretraga.length;i++){
          this.najmanjeCenePretraga[i]=Number.MAX_SAFE_INTEGER
          this.artikliPretraga[i].robaobjekat.forEach(ro => {
            if(ro.prodajnaCena<this.najmanjeCenePretraga[i]){
              this.najmanjeCenePretraga[i]=ro.prodajnaCena
            }
          });
        }
        }
      })
    }else{
      this.artiklService.pretragaProizvodjac(this.zaPretragu).subscribe((data:Artikl[])=>{
        if(data){
          this.artikliPretraga=data;
        for(let i=0;i<this.artikliPretraga.length;i++){
          this.najmanjeCenePretraga[i]=Number.MAX_SAFE_INTEGER
          this.artikliPretraga[i].robaobjekat.forEach(ro => {
            if(ro.prodajnaCena<this.najmanjeCenePretraga[i]){
              this.najmanjeCenePretraga[i]=ro.prodajnaCena
            }
          });
        }
        }
      })
    }
  }
  logout(){
    sessionStorage.clear()
    localStorage.clear()
    this.router.navigate([''])
  }
}
