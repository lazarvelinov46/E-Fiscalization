import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { KorisnikService } from '../korisnik.service';
import { Korisnik } from '../model/korisnik';

@Component({
  selector: 'app-loginadmin',
  templateUrl: './loginadmin.component.html',
  styleUrls: ['./loginadmin.component.css']
})
export class LoginadminComponent implements OnInit {

  constructor(private korisnikService:KorisnikService,private router:Router) { }

  ngOnInit(): void {
  }
  username:string;
  password:string;
  message:string;
  korisnik:Korisnik;

  login(){
    this.korisnikService.loginAdmin(this.username, this.password).subscribe((korisnikFromDB: Korisnik)=>{
      if(korisnikFromDB!=null){
        this.korisnik=korisnikFromDB
        localStorage.setItem('ulogovan',JSON.stringify(this.korisnik))
        this.router.navigate(['administrator']);
      }
      else{
        this.message="Pogresno korisnicko ime ili lozinka"
      }
    })
    
  }
}
