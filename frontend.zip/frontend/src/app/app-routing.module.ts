import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdministratorComponent } from './administrator/administrator.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { KupacComponent } from './kupac/kupac.component';
import { LoginComponent } from './login/login.component';
import { NaruciociComponent } from './narucioci/narucioci.component';
import { PreduzeceComponent } from './preduzece/preduzece.component';
import { PreduzeceprviComponent } from './preduzeceprvi/preduzeceprvi.component';
import { RobeuslugeComponent } from './robeusluge/robeusluge.component';
import { RasporedComponent } from './raspored/raspored.component';
import { RasporedstolovaComponent } from './rasporedstolova/rasporedstolova.component';
import { IzdavanjeracunaComponent } from './izdavanjeracuna/izdavanjeracuna.component';
import { PregledizvestajaComponent } from './pregledizvestaja/pregledizvestaja.component';
import { PregledracunaComponent } from './pregledracuna/pregledracuna.component';
import { LoginadminComponent } from './loginadmin/loginadmin.component';
const routes: Routes = [
  {path:'',component:LoginComponent},
  {path:'kupac',component:KupacComponent},
  {path:'administrator',component:AdministratorComponent},
  {path:'preduzece',component:PreduzeceComponent},
  {path:'changepassword',component:ChangepasswordComponent},
  {path:'preduzeceprvi',component:PreduzeceprviComponent},
  {path:'narucioci',component:NaruciociComponent},
  {path:'robeusluge',component:RobeuslugeComponent},
  {path:'raspored',component:RasporedComponent},
  {path:'rasporedstolova',component:RasporedstolovaComponent},
  {path:'izdavanjeracuna',component:IzdavanjeracunaComponent},
  {path:'pregledizvestaja',component:PregledizvestajaComponent},
  {path:'pregledracuna',component:PregledracunaComponent},
  {path:'loginadmin',component:LoginadminComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
