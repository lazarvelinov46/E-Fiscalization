import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { KorisnikService } from '../korisnik.service';
import { Korisnik } from '../model/korisnik';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  constructor(private router:Router,private korisnikService:KorisnikService) { }

  ngOnInit(): void {
  }
  starasif:string;
  novasif:string;
  opetnovasif:string;
  korisnik:Korisnik;
  message:string;
  
  sifraIzraz = new RegExp("^[A-Za-z](?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{7,11}$");
  
  changePassword(){
    
    this.korisnik=JSON.parse(localStorage.getItem('ulogovan'));
    if(this.sifraIzraz.test(this.novasif)==false){
      this.message="Sifra nije u odgovarajucem obliku!!!"
      return;
    }
    if(this.novasif!=this.opetnovasif){
      this.message="Nisu iste sifra i potvrda sifre"
    }else{
      this.korisnikService.changePassword(this.korisnik.username,this.novasif,this.starasif).subscribe(respObj=>{
        if(respObj['message']=='ok'){
          this.message = 'Uspesno promenjena sifra'
          sessionStorage.clear();
          this.router.navigate(['']);
        }
        else if(respObj['message']=='error'){
          this.message = 'Pogresna stara sifra'
        }
      })
    }
  }

}
